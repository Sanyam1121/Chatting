const express = require('express');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

let usersConnected = 0;

io.on('connection', (socket) => {
  if (usersConnected >= 2) {
    socket.disconnect();
    return;
  }

  usersConnected++;
  console.log('User connected');

  socket.on('chat message', (data) => {
    io.emit('chat message', data);
  });

  socket.on('disconnect', () => {
    usersConnected--;
    console.log('User disconnected');
  });
});

app.use(express.static('public'));

server.listen(3000, () => {
  console.log('Server running on http://localhost:3000');
});
